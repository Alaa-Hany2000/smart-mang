<?php

namespace App\Modules\Barren\Models;

use Illuminate\Database\Eloquent\Model;

class Barren extends Model
{
    //
}
