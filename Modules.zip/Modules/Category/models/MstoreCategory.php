<?php

namespace App\Modules\Category\models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MstoreCategory extends Model
{
    use HasFactory;
}
