<?php

namespace App\Modules\Customeres\models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerMstores extends Model
{
    use HasFactory;
}
