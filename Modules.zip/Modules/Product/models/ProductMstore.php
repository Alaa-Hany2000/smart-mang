<?php

namespace App\Modules\Product\models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductMstore extends Model
{
    use HasFactory;
}
