<?php

namespace App\Modules\Stores\models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mstore extends Model
{
    use HasFactory;
    protected $fillable=array('*');
}
